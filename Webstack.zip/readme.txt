one-click "Webstack Windows Installation"

 - sublime html editor ( type subl from powershell command prompt )
 - node, npm
 - chocolatey
 - yeoman
 - node express.js
 - subl

https://gist.github.com/valerysntx/755f234af96ca5d5aa63

